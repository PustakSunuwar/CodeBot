//import libraries
import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Stack;
import java.util.List;

import java.util.ArrayList;


public class CodeValidator {

        public static void main(String[] args) {
        	runBracketsChecker("Demo.java");
        }
    
        public static void runBracketsChecker(String fileName) {
           try {
         ArrayList<String> lines = readInFile(fileName);
         
         boolean mismatched = containsMismatchedBrackets(lines);
         if(mismatched) {
            System.out.printf("%s contains mismatched brackets.\n", fileName);
         }
      } catch(IOException e) {
         System.out.printf("File \"%s\" not found.\n", fileName);
         System.out.println("Please specify a valid file name as input for this program.");
      }
        }
        
   /**
    * Read in a file, returning an ArrayList<String> containing all lines in that file.
    * fileName the name of the file to read int
    * an ArrayList<String> containing all lines in this file
    * IOException if the file can not be opened or closed
   */
   public static ArrayList<String> readInFile(String fileName) throws IOException {
      
	   File myFile = new File("src/Demo.java");
	   FileInputStream file = new FileInputStream(myFile);
	   Scanner in = new Scanner(file);
      ArrayList<String> lines = new ArrayList<String>();
      while(in.hasNextLine()) {
         lines.add(in.nextLine());
      }
      file.close();
      return lines;
   }

   /**
   * Return true if the list of lines contains mismatched parentheses (),
   * curly braces {}, or square brackets [].
   * This method also prints out error messages if
   * mismatched brackets are discovered.
   * lines the list of lines
   * true if the lines contain mismatched brackets, false
   * otherwise
   */
   public static boolean containsMismatchedBrackets(List<String> lines) {
      
      Stack<String> s = new Stack<String>();
      String character;
      for (String line : lines) {
         for (int i = 0; i < line.length(); i++) {
            character = String.valueOf(line.charAt(i));
            if (character.equals("{") || character.equals("(") || character.equals("[")) {
               s.push(character);
            }
            
            if (s.isEmpty() && (character.equals("}") || character.equals(")") || character.equals("]"))){
               System.out.printf("Error! Stack empty, no opening bracket to match closing %s.\n", character);
               return true;
            }
            
            if (character.equals("]")) {
               String c = s.pop();
               if (!c.equals("[")) {
                  System.out.printf("Error! Cannot close ]. Does not match %s popped off the stack.\n", c);
                  return true;
               }
            }
            if (character.equals("}")) {
               String c = s.pop();
               if (!c.equals("{")) {
                  System.out.printf("Error! Cannot close }. Does not match %s popped off the stack.\n", c);
                  return true;
               }
            }
            
            if (character.equals(")")) {
               String c = s.pop();
               if (!c.equals("(")) {
                  System.out.printf("Error! Cannot close ). Does not match %s popped off the stack.\n", c);
                  return true;
               }
            }
         }
      }
      
      if (!s.isEmpty()) {
         System.out.printf("Error! One or more opening brackets never closed. Closing %s is still on the stack.\n", s.peek());
         return true;
      }
      else {
         System.out.println("All brackets match");
         return false;
      }
   }
}