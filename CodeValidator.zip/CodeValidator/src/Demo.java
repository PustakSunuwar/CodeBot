import javax.swing.JOptionPane;

public class Demo
{
	public static void main (String[] args)
	{
	int first_int = 0;
	int second_int = 0;
	int x = 0;
	String int_string;
	
	int_string = JOptionPane.showInputDialog("Enter first integer: ");
	first_int = Integer.parseInt(int_string);
	int_string = JOptionPane.showInputDialog("Enter second integer: ");
	second_int = Integer.parseInt(int_string);
	
	   x = first_int + second_int;
	   JOptionPane.showMessageDialog(null,  "first + second = " + x);
	   
	   x = first_int - second_int;
	   JOptionPane.showMessageDialog(null,  "first - second = " + x);
	  
	   x = first_int / second_int;
	   JOptionPane.showMessageDialog(null,  "first / second = " + x);
	   
	   x =  first_int * second_int;
	   JOptionPane.showMessageDialog(null,  "first * second = " + x);
	      
	
	}
}